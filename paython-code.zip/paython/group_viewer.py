# ===============================================
# 🧠 كود واجهة عرض مجموعة البطاريات مع شرح مفصل
# ===============================================

# ✅ استيراد المكتبات المطلوبة
import os  # للتعامل مع نظام الملفات واستعراض المجلدات
import json  # لقراءة ملفات JSON التي تحتوي على بيانات البطاريات
import customtkinter as ctk  # مكتبة واجهات محسنة تعتمد على Tkinter
from tkinter import messagebox, ttk  # messagebox للرسائل المنبثقة، و ttk لإنشاء جدول Treeview
from battery_viewer import BatteryDataViewer  # استيراد نافذة عرض بيانات بطارية مفردة

# ✅ إنشاء نافذة فرعية لعرض معلومات مجموعة من البطاريات
class GroupViewerWindow(ctk.CTkToplevel):
    def __init__(self, parent, group_name, group_path):
        super().__init__(parent)

        # 🎯 إعدادات أولية للنافذة
        self.title(f"Group: {group_name}")  # عنوان النافذة يظهر اسم المجموعة
        self.geometry("900x650")  # حجم النافذة
        self.group_path = group_path  # مسار المجلد الذي يحتوي على ملفات البطاريات

        # 🧾 عنوان يوضح محتوى الجدول
        ctk.CTkLabel(self, text="Battery Voltage Readings at Key Seconds", font=("Helvetica", 18, "bold")).pack(pady=10)

        # 📊 إنشاء جدول لعرض البيانات الملخصة لكل بطارية
        self.summary_table = ttk.Treeview(self)
        self.summary_table["columns"] = ("battery", "-2", "5", "28", "33", "diff_5_max", "mah_max", "percent")
        self.summary_table["show"] = "headings"  # إظهار رؤوس الأعمدة فقط دون العمود الأول الافتراضي

        # ✅ تحديد الأعمدة اللي راح تظهر في الجدول
        self.summary_table["columns"] = (
            "battery", "-2", "5", "max", "after_3sec",
            "diff_5_max", "mah_max", "percent"
        )
        self.summary_table["show"] = "headings"  # فقط رؤوس الأعمدة

        # 🏷️ إعداد رؤوس الأعمدة وأسمائها
        self.summary_table.heading("battery", text="Battery")
        self.summary_table.column("battery", anchor="center", width=80)

        for col in ("-2", "5", "max", "after_3sec"):
            self.summary_table.heading(col, text=f"sec={col}")
            self.summary_table.column(col, anchor="center", width=100)

        self.summary_table.heading("diff_5_max", text="ΔV (5s - max)")  # فرق الجهد بين ثانية 5 و max
        self.summary_table.column("diff_5_max", anchor="center", width=120)

        self.summary_table.heading("mah_max", text="mAh @max")
        self.summary_table.column("mah_max", anchor="center", width=120)

        self.summary_table.heading("percent", text="% of Ref")
        self.summary_table.column("percent", anchor="center", width=100)

        # ✅ عرض الجدول
        self.summary_table.pack(pady=10, padx=10, fill="x")


        # 🖱️ ربط النقر المزدوج على الصف لعرض نافذة تكبير
        self.summary_table.bind("<Double-1>", self.on_table_double_click)

        # 🔘 إطار يحتوي على أزرار التفاعل
        button_frame = ctk.CTkFrame(self)
        button_frame.pack(pady=5)

        ctk.CTkButton(button_frame, text="🔄 Refresh Table", command=self.load_key_readings).pack(side="left", padx=10)
        ctk.CTkButton(button_frame, text="🔍 Group Similar Batteries", command=self.group_batteries).pack(side="left", padx=10)

        # 🧱 إطار يحتوي على أزرار لعرض كل بطارية بشكل منفصل
        ctk.CTkLabel(self, text="Battery Details:", font=("Helvetica", 14)).pack(pady=5)
        self.button_frame = ctk.CTkScrollableFrame(self)
        self.button_frame.pack(expand=True, fill="both", padx=20, pady=10)

        # 🚀 تحميل الأزرار والبيانات عند بدء التشغيل
        self.load_battery_buttons()
        self.load_key_readings()

    # 🔘 إنشاء أزرار لكل بطارية موجودة في المجلد
    def load_battery_buttons(self):
        # مسح الأزرار القديمة إذا كان فيه إعادة تحميل
        for widget in self.button_frame.winfo_children():
            widget.destroy()

        ref_capacity = None
        try:
            with open("ref_capacity.json", "r", encoding="utf-8") as f:
                data = json.load(f)
                ref_capacity = float(data.get("value", None))
        except:
            ref_capacity = None

        for file in os.listdir(self.group_path):
            if file.endswith(".json"):
                batt_num = file.replace(".json", "")
                display_text = f"Battery {batt_num}"

                # نحاول نحسب التقدير التقريبي
                if ref_capacity:
                    try:
                        file_path = os.path.join(self.group_path, file)
                        with open(file_path, "r", encoding="utf-8") as f:
                            data = json.load(f)
                            entry_28 = next((d for d in data if d.get("sec") == 28), None)
                            if entry_28 and "mah" in entry_28:
                                mah_at_max_sec = float(entry_28["mah"])
                                percent = mah_at_max_sec / ref_capacity
                                estimated_capacity = int(percent * ref_capacity)
                                display_text += f"\t≈ {estimated_capacity} mAh"
                    except:
                        pass  # إذا صار خطأ، منترك النص بدون تقدير

                # إنشاء الزر
                btn = ctk.CTkButton(self.button_frame, text=display_text,
                                    command=lambda b=batt_num: self.open_battery_data(b))
                btn.pack(pady=5, fill="x")


    # 📂 فتح نافذة تفاصيل بطارية مفردة
    def open_battery_data(self, batt_num):
        file_path = os.path.join(self.group_path, f"{batt_num}.json")
        if not os.path.exists(file_path):
            messagebox.showerror("Error", "Battery file not found.")
            return
        BatteryDataViewer(self, batt_num, file_path)

    # 📥 تحميل وقراءة بيانات الجهد من الملفات لكل بطارية
    def load_key_readings(self):
        self.summary_table.delete(*self.summary_table.get_children())  # حذف أي بيانات سابقة
        key_secs_static = [-2, 5]  # الثواني الثابتة

        for file in os.listdir(self.group_path):
            if file.endswith(".json"):
                batt_num = file.replace(".json", "")
                file_path = os.path.join(self.group_path, file)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        data = json.load(f)

                        # إيجاد أعلى قيمة sec في الملف
                        max_sec = max(d.get("sec", 0) for d in data)

                        # duration = max_sec - 3
                        duration = max_sec - 3

                        # حساب القيم الديناميكية حسب duration
                        max_2 = duration - 2       # = max_sec - 5
                        after_3sec = duration + 3       # = max_sec

                        # قراءة السعة المرجعية من الملف (إذا موجودة)
                        ref_value = None
                        try:
                            with open("ref_capacity.json", "r", encoding="utf-8") as ref_file:
                                ref_data = json.load(ref_file)
                                ref_value = float(ref_data.get("value", 0))
                        except:
                            pass

                        # نحدد كل الثواني اللي نحتاجها
                        key_secs = key_secs_static + [max_2, after_3sec]

                        readings = {}
                        for sec in key_secs:
                            entry = next((d for d in data if d.get("sec") == sec), None)
                            vbat = round(entry.get("v_bat", 0), 3) if entry else None
                            readings[sec] = vbat

                        # mah عند max_2
                        mah_at_max_sec = "-"
                        entry_28 = next((d for d in data if d.get("sec") == max_2), None)
                        if entry_28:
                            mah_at_max_sec = round(entry_28.get("mah", 0), 1)
                            percent = "-"
                            if entry_28 and ref_value and ref_value > 0:
                                percent = round((entry_28.get("mah", 0) / ref_value) * 100, 1)

                        # فرق الجهد بين ثانية 5 و max_2
                        if readings.get(5) is not None and readings.get(max_2) is not None:
                            diff = round(readings[5] - readings[max_2], 3)
                        else:
                            diff = "-"

                        # بناء صف الجدول
                        row = [
                            batt_num,
                            readings.get(-2, "-") or "-",
                            readings.get(5, "-") or "-",
                            readings.get(max_2, "-") or "-",
                            readings.get(after_3sec, "-") or "-",
                            diff,
                            mah_at_max_sec,
                            f"{percent}%" if percent != "-" else "-"
                        ]
                        self.summary_table.insert("", "end", values=row)

                except Exception as e:
                    print(f"Error reading file {file}: {e}")

    # 🔍 تكبير الجدول في نافذة جديدة عند النقر المزدوج
    def on_table_double_click(self, event):
        new_window = ctk.CTkToplevel(self)
        new_window.geometry("900x700")
        new_window.title("Expanded Voltage Table")

        new_table = ttk.Treeview(new_window, columns=self.summary_table["columns"], show="headings")
        for col in self.summary_table["columns"]:
            new_table.heading(col, text=col)
            new_table.column(col, anchor="center", width=200)

        new_table.pack(expand=True, fill="both")

        for item in self.summary_table.get_children():
            values = self.summary_table.item(item)["values"]
            new_table.insert("", "end", values=values)

    # 🧠 تجميع البطاريات التي لها قراءات متقاربة عند الثواني المهمة
    def group_batteries(self):
        key_secs = [-2, 5, 28]  # الثواني التي نعتمدها للمقارنة
        battery_data = {}

        # قراءة الجهد لكل بطارية عند الثواني المحددة
        for file in os.listdir(self.group_path):
            if file.endswith(".json"):
                batt_num = file.replace(".json", "")
                file_path = os.path.join(self.group_path, file)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        readings = {}
                        for sec in key_secs:
                            entry = next((d for d in data if d.get("sec") == sec), None)
                            if entry:
                                readings[sec] = round(entry.get("v_bat", 0), 3)
                        if len(readings) == 3:
                            battery_data[batt_num] = readings
                except:
                    continue

        # مقارنة كل بطاريتين وتجميع المتشابهات
        used = set()
        groups = []

        for b1, r1 in battery_data.items():
            if b1 in used:
                continue
            group = [b1]
            used.add(b1)

            for b2, r2 in battery_data.items():
                if b2 in used or b1 == b2:
                    continue
                match = all(abs(r1[sec] - r2[sec]) <= 0.06 for sec in key_secs)
                if match:
                    group.append(b2)
                    used.add(b2)

            groups.append(group)

        # عرض المجموعات في نافذة جديدة
        group_win = ctk.CTkToplevel(self)
        group_win.geometry("600x600")
        group_win.title("Grouped Batteries")

        for idx, group in enumerate(groups, 1):
            label = ctk.CTkLabel(group_win, text=f"Group {idx}: {', '.join(group)}", font=("Helvetica", 14))
            label.pack(pady=3)
