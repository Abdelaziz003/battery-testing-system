import customtkinter as ctk
import serial
import serial.tools.list_ports
import threading
import json
import os
from tkinter import messagebox

from group_viewer import GroupViewerWindow


class BatteryTesterApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Battery Testing Program")
        self.geometry("850x700")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")

        self.arduino = None
        self.is_running = False
        self.collected_data = {}
        self.ref_capacity_value = None

        # --- إطار الاتصال (Top frame) ---
        connection_frame = ctk.CTkFrame(self)
        connection_frame.grid(row=0, column=0, padx=10, pady=10, sticky="ew")
        connection_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(connection_frame, text="Select Arduino Port:").grid(row=0, column=0, padx=5, pady=5)
        self.port_menu = ctk.CTkOptionMenu(connection_frame, values=[""])
        self.port_menu.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        self.connect_button = ctk.CTkButton(connection_frame, text="Connect", command=self.toggle_connection)
        self.connect_button.grid(row=0, column=2, padx=5, pady=5)
        self.refresh_ports_button = ctk.CTkButton(connection_frame, text="Refresh Ports", command=self.update_ports)
        self.refresh_ports_button.grid(row=0, column=3, padx=5, pady=5)
        self.update_ports()

        # --- إطار التحكم بالاختبار (Middle frame) ---
        control_frame = ctk.CTkFrame(self)
        control_frame.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
        control_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(control_frame, text="Group Name:").grid(row=0, column=0, padx=5, pady=5)
        self.group_name_combobox = ctk.CTkComboBox(control_frame, values=[])
        self.group_name_combobox.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        self.update_group_names()

        ctk.CTkLabel(control_frame, text="Number of Batteries:").grid(row=1, column=0, padx=5, pady=5)
        self.battery_count_menu = ctk.CTkOptionMenu(control_frame, values=['1', '2', '3', '4', '5'])
        self.battery_count_menu.set('1')
        self.battery_count_menu.grid(row=1, column=1, padx=5, pady=5, sticky="w")

        # --- أزرار الاختبار بأنواع مختلفة ---
        self.default_test_button = ctk.CTkButton(control_frame, text="Start 30s Test", command=self.start_default_test, state="disabled")
        self.default_test_button.grid(row=0, column=2, padx=10, pady=5)

        self.custom_test_button = ctk.CTkButton(control_frame, text="Start Custom Duration", command=self.start_custom_test, state="disabled")
        self.custom_test_button.grid(row=1, column=2, padx=10, pady=5)

        ctk.CTkLabel(control_frame, text="Duration (sec):").grid(row=2, column=0, padx=5, pady=5)
        self.duration_entry = ctk.CTkEntry(control_frame)
        self.duration_entry.grid(row=2, column=1, padx=5, pady=5, sticky="ew")

        self.full_test_button = ctk.CTkButton(control_frame, text="Start FULLTEST", command=self.start_full_test, state="disabled")
        self.full_test_button.grid(row=2, column=2, padx=10, pady=5)

        self.view_group_button = ctk.CTkButton(control_frame, text="View Group Data", command=self.open_group_view)
        self.view_group_button.grid(row=3, column=0, columnspan=3, pady=10)

        ctk.CTkLabel(control_frame, text="السعة المرجعية (mAh):").grid(row=4, column=0, padx=5, pady=5)
        self.ref_capacity_entry = ctk.CTkEntry(control_frame)
        self.ref_capacity_entry.grid(row=4, column=1, padx=5, pady=5, sticky="ew")
        self.save_ref_button = ctk.CTkButton(control_frame, text="Save capacity", command=self.save_ref_capacity)
        self.save_ref_button.grid(row=4, column=2, padx=5, pady=5)

        self.result_label = ctk.CTkLabel(control_frame, text="", text_color="black")
        self.result_label.grid(row=5, column=0, columnspan=3, pady=5)

        self.load_ref_capacity()

        # --- إطار عرض السجل (Bottom frame) ---
        log_frame = ctk.CTkFrame(self)
        log_frame.grid(row=2, column=0, padx=10, pady=10, sticky="nsew")
        log_frame.grid_rowconfigure(0, weight=1)
        log_frame.grid_columnconfigure(0, weight=1)

        self.log_textbox = ctk.CTkTextbox(log_frame, state="disabled", font=("Consolas", 12))
        self.log_textbox.grid(row=0, column=0, sticky="nsew")

    # --- دالة بدء فحص 30 ثانية (افتراضي) ---
    def start_default_test(self):
        self.send_test_command("START", duration=None)

    # --- دالة بدء فحص بمدة مخصصة (حسب الإدخال) ---
    def start_custom_test(self):
        duration_text = self.duration_entry.get().strip()
        if not duration_text.isdigit():
            messagebox.showwarning("Invalid Input", "Please enter a valid number of seconds.")
            return
        self.send_test_command("START", duration=int(duration_text))

    # --- دالة بدء فحص FULLTEST (تفريغ كامل) ---
    def start_full_test(self):
        self.send_test_command("FULLTEST")

    # --- دالة إرسال أمر الفحص للأردوينو مع تحديد نوع الفحص والمدة ---
    def send_test_command(self, mode, duration=None):
        group_name = self.group_name_combobox.get().strip()
        battery_count_str = self.battery_count_menu.get()

        if not group_name:
            messagebox.showwarning("Warning", "Please select or enter a group name.")
            return

        battery_count = int(battery_count_str)

        ref_text = self.ref_capacity_entry.get().strip()
        self.log_message(f"Reference capacity set to: {self.ref_capacity_value}")
        try:
            self.ref_capacity_value = float(ref_text) if ref_text else None
        except ValueError:
            self.ref_capacity_value = None
            messagebox.showwarning("تنبيه", "قيمة السعة المرجعية غير صالحة. سيتم تجاهل المقارنة.")

        self.collected_data = {}
        self.data_path = os.path.join("data", "groups", group_name)
        os.makedirs(self.data_path, exist_ok=True)

        existing_files = os.listdir(self.data_path)
        existing_numbers = [int(os.path.splitext(f)[0]) for f in existing_files if f.endswith(".json") and f[:-5].isdigit()]
        starting_index = max(existing_numbers, default=0) + 1
        new_numbers = list(range(starting_index, starting_index + battery_count))
        self.current_battery_numbers = list(map(str, new_numbers))

        battery_numbers_str = ",".join(map(str, range(1, battery_count + 1)))

        # --- تكوين أمر الإرسال حسب نوع الفحص ---
        if mode == "START":
            command = f"START:{battery_numbers_str}"
            if duration is not None:
                command += f":{duration}"   # نضيف مدة الاختبار إذا تم تحديدها
        elif mode == "FULLTEST":
            command = f"FULLTEST:{battery_numbers_str}"
        else:
            return

        self.log_message(f"--- Starting test for group: {group_name} ---")
        self.log_message(f"New batteries will be saved as files: {', '.join(self.current_battery_numbers)}")
        self.arduino.write((command + "\n").encode('utf-8'))

        # --- تعطيل أزرار البدء لمنع تكرار الإرسال أثناء الفحص ---
        self.default_test_button.configure(state="disabled")
        self.custom_test_button.configure(state="disabled")
        self.full_test_button.configure(state="disabled")
    # === تحديث أسماء المجموعات المتوفرة (المجلدات داخل data/groups) ===
    def update_group_names(self):
        groups_path = os.path.join("data", "groups")
        os.makedirs(groups_path, exist_ok=True)  # تأكد من وجود مجلد المجموعات
        try:
            # احصل فقط على المجلدات داخل المسار
            group_dirs = [d for d in os.listdir(groups_path) if os.path.isdir(os.path.join(groups_path, d))]
            self.group_name_combobox.configure(values=group_dirs)
            if group_dirs:
                # اختيار أول مجموعة في القائمة بشكل افتراضي
                self.group_name_combobox.set(group_dirs[0])
        except OSError as e:
            self.log_message(f"Error reading groups: {e}")

    # === وظيفة لإضافة رسالة إلى سجل النص مع التمرير التلقائي للأسفل ===
    def log_message(self, message):
        self.log_textbox.configure(state="normal")
        self.log_textbox.insert("end", message + "\n")
        self.log_textbox.configure(state="disabled")
        self.log_textbox.see("end")

    # === تحديث قائمة المنافذ المتاحة للاتصال ===
    def update_ports(self):
        ports = [port.device for port in serial.tools.list_ports.comports()]
        self.port_menu.configure(values=ports if ports else ["No Ports Found"])
        if ports:
            self.port_menu.set(ports[0])

    # === تبديل حالة الاتصال (اتصال أو قطع) ===
    def toggle_connection(self):
        if self.arduino and self.arduino.is_open:
            self.disconnect()
        else:
            self.connect()

    # === محاولة الاتصال بمنفذ الأردوينو ===
    def connect(self):
        selected_port = self.port_menu.get()
        if not selected_port or "No Ports" in selected_port:
            messagebox.showerror("Error", "No Arduino port found. Please connect your Arduino.")
            return
        try:
            self.arduino = serial.Serial(selected_port, 9600, timeout=1)
            self.log_message(f"Connected to {selected_port} successfully.")
            self.connect_button.configure(text="Disconnect")
            self.default_test_button.configure(state="normal")
            self.custom_test_button.configure(state="normal")
            self.full_test_button.configure(state="normal")
            self.is_running = True
            # بدء تشغيل خيط لقراءة البيانات من الأردوينو بشكل غير متزامن
            self.read_thread = threading.Thread(target=self.read_from_arduino, daemon=True)
            self.read_thread.start()
        except serial.SerialException as e:
            messagebox.showerror("Connection Error", f"Cannot open port {selected_port}.\n{e}")

    # === قطع الاتصال بالأردوينو ===
    def disconnect(self):
        self.is_running = False
        if self.arduino:
            self.arduino.close()
        self.log_message("Disconnected.")
        self.connect_button.configure(text="Connect")
        self.default_test_button.configure(state="disabled")
        self.custom_test_button.configure(state="disabled")
        self.full_test_button.configure(state="disabled")

    # === وظيفة تعمل في خلفية الخيط لقراءة البيانات القادمة من الأردوينو ===
    def read_from_arduino(self):
        while self.is_running and self.arduino and self.arduino.is_open:
            try:
                line = self.arduino.readline().decode('utf-8').strip()
                if line:
                    # تمرير السطر للمعالجة في thread الرئيسي
                    self.after(0, self.process_line, line)
            except (serial.SerialException, UnicodeDecodeError):
                if self.is_running:
                    self.after(0, self.disconnect)
                break

    # === معالجة سطر البيانات القادم من الأردوينو ===
    def process_line(self, line):
        self.log_message(line)  # عرض السطر في سجل النص
        self.parse_and_store(line)  # تخزين البيانات وتحليلها

    # === بدء اختبار البطاريات ===
    def start_test(self):
        group_name = self.group_name_combobox.get().strip()
        battery_count_str = self.battery_count_menu.get()

        if not group_name:
            messagebox.showwarning("Warning", "Please select or enter a group name.")
            return

        battery_count = int(battery_count_str)

        ref_text = self.ref_capacity_entry.get().strip()
        ref_capacity_value = ref_text
        self.log_message(f"Reference capacity set to: {self.ref_capacity_value}")
        try:
            self.ref_capacity_value = float(ref_text) if ref_text else None
        except ValueError:
            self.ref_capacity_value = None
            messagebox.showwarning("تنبيه", "قيمة السعة المرجعية غير صالحة. سيتم تجاهل المقارنة.")


        self.collected_data = {}
        self.data_path = os.path.join("data", "groups", group_name)
        os.makedirs(self.data_path, exist_ok=True)

        # 🔎 تحقق من الملفات الموجودة في مجلد المجموعة لتوليد أرقام جديدة للملفات
        existing_files = os.listdir(self.data_path)
        existing_numbers = []
        for fname in existing_files:
            if fname.endswith(".json"):
                try:
                    num = int(os.path.splitext(fname)[0])
                    existing_numbers.append(num)
                except ValueError:
                    continue  # تجاهل الملفات غير الرقمية

        starting_index = max(existing_numbers, default=0) + 1  # الرقم الأول للملف الجديد
        new_numbers = list(range(starting_index, starting_index + battery_count))
        self.current_battery_numbers = list(map(str, new_numbers))  # أسماء الملفات الجديدة

        # الأوامر التي سترسل للأردوينو تبدأ من 1, 2, ...
        battery_numbers_str = ",".join(map(str, range(1, battery_count + 1)))
        command = f"START:{battery_numbers_str}\n"

        self.log_message(f"--- Starting test for group: {group_name} ---")
        self.log_message(f"New batteries will be saved as files: {', '.join(self.current_battery_numbers)}")
        self.arduino.write(command.encode('utf-8'))
        self.start_button.configure(state="disabled")

    # === تحليل السطر وحفظ البيانات في القاموس المناسب ===
    def parse_and_store(self, line):
        if "BATT:" in line:
            parts = line.split('|')
            data_point = {}
            batt_num_str = ""
            for part in parts:
                key, val = part.split(':', 1)
                if key == "BATT":
                    batt_num_str = val
                else:
                    try:
                        data_point[key.lower()] = float(val)
                    except ValueError:
                        data_point[key.lower()] = val
            if batt_num_str:
                if batt_num_str not in self.collected_data:
                    self.collected_data[batt_num_str] = []
                self.collected_data[batt_num_str].append(data_point)

        elif "TEST_COMPLETE" in line:
            self.save_results()
            self.default_test_button.configure(state="normal")
            self.custom_test_button.configure(state="normal")
            self.full_test_button.configure(state="normal")

    # === حفظ نتائج الفحص في ملفات JSON منفصلة لكل بطارية ===
    def save_results(self):
        if not self.collected_data:
            self.log_message("No data collected to save.")
            return

        # ترتيب المفاتيح لضمان حفظ الملفات بالترتيب الصحيح
        sorted_keys = sorted(self.collected_data.keys(), key=lambda x: int(x))

        for idx, batt_key in enumerate(sorted_keys):
            if idx >= len(self.current_battery_numbers):
                self.log_message("More data collected than expected.")
                continue

            save_filename = self.current_battery_numbers[idx]  # اسم الملف، مثل "4"
            data_list = self.collected_data[batt_key]

            file_path = os.path.join(self.data_path, f"{save_filename}.json")
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data_list, f, indent=4, ensure_ascii=False)
                self.log_message(f"✅ Battery {batt_key} results saved as {save_filename}.json")
            except IOError as e:
                self.log_message(f"❌ Failed to save battery {batt_key} data: {e}")
        
        # عرض السعة عند الثانية 28 لكل بطارية بعد الانتهاء
        result_text = ""
        for batt_key in sorted_keys:
            data_list = self.collected_data[batt_key]
            mah_at_28 = None
            for item in data_list:
                if int(item.get("sec", -1)) == 28:
                    mah_at_28 = item.get("mah")
                    break
            if mah_at_28 is not None:
                if self.ref_capacity_value:
                    percentage = (mah_at_28 / self.ref_capacity_value) * 100
                    result_text += f"Battery {batt_key}: {mah_at_28:.1f} mAh — {percentage:.1f}% of reference\n"
                else:
                    result_text += f"Battery {batt_key}: {mah_at_28:.1f} mAh\n"
            else:
                result_text += f"⚠️ No reading at second 28 for battery {batt_key}\n"


        self.result_label.configure(text=result_text)

        self.update_group_names()  # تحديث قائمة المجموعات بعد الحفظ
        messagebox.showinfo("Test Complete", f"All results saved in:\n{self.data_path}")


    # === فتح نافذة عرض بيانات المجموعة المحددة ===
    def open_group_view(self):
        group_name = self.group_name_combobox.get().strip()
        if not group_name:
            messagebox.showwarning("Warning", "Please select a group.")
            return

        data_folder = os.path.join("data", "groups", group_name)
        if not os.path.exists(data_folder):
            messagebox.showerror("Error", f"Folder does not exist: {data_folder}")
            return

        GroupViewerWindow(self, group_name, data_folder)

    # دالة لتحميل السعة المرجعية
    def load_ref_capacity(self):
        try:
            with open("ref_capacity.json", "r", encoding="utf-8") as f:
                data = json.load(f)
                value = data.get("value", "")
                self.ref_capacity_entry.delete(0, "end")
                self.ref_capacity_entry.insert(0, str(value))
                try:
                    self.ref_capacity_value = float(value)
                except:
                    self.ref_capacity_value = None
        except FileNotFoundError:
            self.log_message("⚠️ ref_capacity.json not found. Using default value.")
        except json.JSONDecodeError:
            self.log_message("⚠️ Error decoding ref_capacity.json.")

    # === دالة لحفظ السعة المرجعية ===
    def save_ref_capacity(self):
        try:
            value = float(self.ref_capacity_entry.get().strip())
            with open("ref_capacity.json", "w", encoding="utf-8") as f:
                json.dump({"value": value}, f, indent=4, ensure_ascii=False)
            self.log_message(f"✅ تم حفظ السعة المرجعية: {value} mAh")
        except ValueError:
            messagebox.showwarning("خطأ", "الرجاء إدخال رقم صحيح للسعة.")



if __name__ == "__main__":
    app = BatteryTesterApp()
    app.mainloop()
