# ===============================================
# 📊 battery_viewer.py - نافذة عرض تفاصيل بطارية واحدة
# ===============================================

# ✅ استيراد المكتبات المطلوبة
import json  # لقراءة بيانات البطارية من ملف JSON
import tkinter.ttk as ttk  # لإنشاء جدول Treeview
import customtkinter as ctk  # مكتبة واجهات محسنة من Tkinter
from tkinter import messagebox  # لعرض رسائل الخطأ
from matplotlib.figure import Figure  # لإنشاء الرسومات البيانية
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  # لعرض الرسم داخل نافذة Tkinter

# ✅ تعريف نافذة عرض بيانات البطارية
class BatteryDataViewer(ctk.CTkToplevel):
    def __init__(self, parent, battery_num, file_path):
        super().__init__(parent)

        # إعدادات النافذة
        self.title(f"Battery Data: {battery_num}")
        self.geometry("1000x600")  # حجم النافذة مناسب لـ 3 رسوم بيانية

        # 🧪 محاولة قراءة بيانات البطارية من الملف
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read data:\n{e}")
            self.destroy()
            return

        # في حال عدم وجود بيانات
        if not data:
            ctk.CTkLabel(self, text="No data to display.").pack(pady=20)
            return

        # ترتيب الأعمدة في الجدول
        ordered_columns = ["sec", "v_bat", "v_shunt_h", "v_shunt_l", "a", "mah"]

        # ✅ إطار يحتوي على الجدول والشريط التمرير
        table_frame = ctk.CTkFrame(self)
        table_frame.pack(expand=True, fill="both", padx=10, pady=10)

        # ✅ إنشاء الجدول
        tree = ttk.Treeview(table_frame, columns=ordered_columns, show="headings")
        tree.pack(side="left", expand=True, fill="both")

        # ✅ إضافة حدث النقر المزدوج لفتح جدول مفصل
        tree.bind("<Double-1>", lambda e: self.expand_table(data, ordered_columns))


        # ✅ إضافة شريط تمرير عمودي
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side="right", fill="y")

        # ✅ ربط الجدول مع شريط التمرير
        tree.configure(yscrollcommand=scrollbar.set)


        for col in ordered_columns:
            tree.heading(col, text=col)
            tree.column(col, anchor="center", width=100)

        for entry in data:
            row = [entry.get(col, "") for col in ordered_columns]
            tree.insert("", "end", values=row)

        # ✅ إيجاد أكبر قيمة للزمن (sec) داخل البيانات
        max_sec = max(entry.get("sec", 0) for entry in data if "sec" in entry)

        # 🎯 فلترة البيانات للرسم: فقط من 0 إلى (max - 3)
        filtered_data = [entry for entry in data if 0 <= entry.get("sec", -1) <= max_sec - 3]



        # استخراج القيم المطلوبة للرسم
        times = [entry.get("sec", 0) for entry in filtered_data]
        currents = [entry.get("a", 0) for entry in filtered_data]
        capacities = [entry.get("mah", 0) for entry in filtered_data]
        voltages = [entry.get("v_bat", 0) for entry in filtered_data]

        # 🎨 إنشاء رسم بياني مكوّن من 3 منحنيات (تيار، سعة، جهد)
        fig = Figure(figsize=(10, 3), dpi=100)
        ax1 = fig.add_subplot(131)  # رسم التيار
        ax2 = fig.add_subplot(132)  # رسم السعة
        ax3 = fig.add_subplot(133)  # رسم الجهد

        # المنحنى 1: التيار مقابل الزمن
        ax1.plot(times, currents, color='blue')
        ax1.set_title("Current (A) vs Time")
        ax1.set_xlabel("Time (sec)")
        ax1.set_ylabel("Current (A)")
        ax1.grid(True)

        # المنحنى 2: السعة مقابل الزمن
        ax2.plot(times, capacities, color='green')
        ax2.set_title("Capacity (mAh) vs Time")
        ax2.set_xlabel("Time (sec)")
        ax2.set_ylabel("Capacity (mAh)")
        ax2.grid(True)

        # المنحنى 3: الجهد مقابل الزمن
        ax3.plot(times, voltages, color='red')
        ax3.set_title("Voltage (V) vs Time")
        ax3.set_xlabel("Time (sec)")
        ax3.set_ylabel("Voltage (V)")
        ax3.grid(True)

        # 🖼️ دمج الرسم البياني في نافذة Tkinter
        canvas = FigureCanvasTkAgg(fig, master=self)
        canvas.draw()
        canvas.get_tk_widget().pack(expand=True, fill="both", padx=10, pady=10)

        # ✅ فتح نافذة جديدة تعرض الجدول بحجم كامل للعرض الكامل
    def expand_table(self, data, columns):
        new_window = ctk.CTkToplevel(self)
        new_window.title("Expanded Battery Table")
        new_window.geometry("1000x600")

        # إطار الجدول مع Scroll
        table_frame = ctk.CTkFrame(new_window)
        table_frame.pack(expand=True, fill="both", padx=10, pady=10)

        tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        tree.grid(row=0, column=0, sticky="nsew")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        vsb.grid(row=0, column=1, sticky="ns")
        tree.configure(yscrollcommand=vsb.set)

        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=tree.xview)
        hsb.grid(row=1, column=0, sticky="ew")
        tree.configure(xscrollcommand=hsb.set)

        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, anchor="center", width=120)

        for entry in data:
            row = [entry.get(col, "") for col in columns]
            tree.insert("", "end", values=row)

